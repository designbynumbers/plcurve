The HOMFLY module
=================

.. automodule:: libpl.pdcode.homfly

.. autoclass:: HOMFLYPolynomial
   :members:

.. autoclass:: HOMFLYTerm
   :members:
