extern int pmParseArgs(int argc, char *argv[], pmSize *Size, pmMethod *Meth, pmOutput *Outp, pmStats *Stat);

