plcurve: Piecewise-Linear Curves (a.k.a. Polygons)
--------------------------------------------------

.. currentmodule:: libpl.plcurve

The PlCurve class
'''''''''''''''''''''''

.. autoclass:: PlCurve
   :members:

Utility classes
'''''''''''''''

.. autoclass:: RandomGenerator
   :members:
