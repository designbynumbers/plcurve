Diagram to image
######################

Utility to produce images from PlanarDiagram objects

Requirements
######################
Python 2.7
plCurve with Python bindings (libpl) installed
spherogram (==1.6.1 works fine)
For SVG: pycairo (maybe cairocffi works too; >=1.8.8-2.1 works)
For GIF or PNG (or...): pil or pillow (pillow recommended)
