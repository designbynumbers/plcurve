extern void pmPrint(pmMap *Map, pmOutput *Outp);

